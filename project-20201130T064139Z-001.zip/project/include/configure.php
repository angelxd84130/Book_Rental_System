<?php
$DBMS = 'mysql';
$dbhost = 'localhost';
$dbuser = 'dbuser';
$dbpwd = 'dbuserdbuser';
$dbname = 'book';
$AttachDir = '/home/doc';
$ItemPerPage = 10;
?>