<HTML>
<HEAD>
<meta HTTP-EQUIV="Content-Type" content="text/html; charset=utf8">
<meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
<link rel="stylesheet" title="Default" href="/css/i4010.css" type="text/css" />
<?php if (!isset($PageTitle)) $PageTitle="網頁程式設計與安全實務"; ?>
<title><?php echo $PageTitle ?></title>
</HEAD>
