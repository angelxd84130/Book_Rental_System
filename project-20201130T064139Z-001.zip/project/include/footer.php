<?php if (!empty($ErrMsg)) { ?>
<Script Language="JavaScript">
<!--
  alert('<?php echo $ErrMsg; ?>');
-->
</SCRIPT>
<?php } ?>
<div id="footer">
<b>網頁程式設計與安全實務</b>
</div>
</body>
</html>